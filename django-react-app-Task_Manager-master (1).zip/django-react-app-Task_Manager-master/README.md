# React-Django-Task_Manager
A Task Manager application created in React as the  client-side and Django Rest Framework as the server-side

React in a nutshell, is a JavaScript library that is great for developing single page applications (SPA) and it has solid documentation if you're interested tor read about React.

And I have a react tutorial video where I explained how React works and how we can connect it to Django in order to send requests from the client to the server and return responses to the client. 

So React serves as the front-end , handling UI through the requests to Django's backend.

The prerequistes for this project are 2 essential elements:

1- Python 3, obviously [ prefereably 3.5 and above] 

2- Node.js - you can install node from nodejs.com and download it very easily, and you can check it if it was properly installed or not : node --version

And we are going to start by our favorite side which is the backend , I'm saying our favorite side because this channel focuses on server-side programming and mainly Python.
